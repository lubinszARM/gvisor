#!/bin/bash

set -x
echo "" > DATA
cd /data
cp uboot.zip /tmp
cd /tmp
unzip uboot.zip
cd u-boot-master/
make rpi_4_defconfig

while [ 1 ]
do
    make clean
    make -j2 
    #`cat /proc/cpuinfo | grep "processor" | wc -l`
    echo " ===== $i times  [`date`]=====" >> DATA
done
