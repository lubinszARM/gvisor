#!/bin/bash
set -x
echo "" > DATA
cd /tmp
wget --no-check-certificate https://mirrors.aliyun.com/linux-kernel/v4.x/linux-4.14.199.tar.xz
sync
tar xvf linux-4.14.199.tar.xz -C /tmp
cd /tmp/linux-4.14.199
make defconfig

while [ 1 ]
do
    make clean
    make -j3
#`cat /proc/cpuinfo | grep "processor" | wc -l`
    echo " ===== $i times  [`date`]=====" >> DATA
done
