#!/bin/bash
# test
set -x
PWD="`pwd`"

KERNEL_BUILD_NUM=10
UBOOT_BUILD_NUM=10

prefix="kvm"

uboot_container()
{
    for ((i=0; i<$UBOOT_BUILD_NUM; i++))
    do
        docker run -d --runtime=runsc \
            --name="uboot-$prefix-$i" \
            --entrypoint=/bin/bash \
            -v $PWD/data/u-boot:/data \
            -v /usr:/usr \
            -v /lib:/lib \
            -v /lib64:/lib64 \
        -v /etc/alternatives:/etc/alternatives \
        ubuntu:18.04 \
            /data/test.sh
    done
}

kernel_container()
{
   for ((i=0; i<$KERNEL_BUILD_NUM; i++))
   do
        docker run -d --runtime=runsc \
            --name="kernel-$prefix-$i" \
            --entrypoint=/bin/bash \
            -v $PWD/data/kernel:/data \
            -v /usr:/usr \
            -v /lib:/lib \
            -v /lib64:/lib64 \
        -v /etc/alternatives:/etc/alternatives \
        ubuntu:18.04 \
            /data/test.sh
    done
}

#################################################################
ps aux |grep runsc | awk '{print $2}' | xargs -i kill -9 {}
sleep 1
docker rm -f `docker  ps -aq`
sleep 1

kernel_container
#uboot_container
